public class Dico extends AbstractDico{
    public Dico() {
        keys = new Object[0];
        values = new Object[0];
    }

    @Override
    public int indexOf(Object key){
        return -1;
    }
}