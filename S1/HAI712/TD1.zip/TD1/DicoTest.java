import org.junit.Assert;
import org.junit.Test;

public class DicoTest{

    @Test
    public void testPut(){
        IDictionary dico = new Dico();
        String key1 = "CHENINI";
        String value1 = "Ayoub";

        dico.put(key1, value1);

        Assert.assertTrue()
    }
}