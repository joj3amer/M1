public class Main {

	public static void main(String[] args){

		IDictionary dico = new Dico();

        String key1 = "CHENINI";
        String value1 = "Ayoub";

        try {
            dico.put(key1, value1);
        } catch (Exception e) {
            System.out.println("Message d'erreur : "+e);
        }
        
        System.out.println("Le dico est de taille : "+ dico.containsKey("CHENINI"));
	}
}