# Coloration graph avec l'algo de chaitin.
TP de Compilation
## Utilisation
executer la classe main, en ayant pris le soins de créer les sommets et arêtes voulus.