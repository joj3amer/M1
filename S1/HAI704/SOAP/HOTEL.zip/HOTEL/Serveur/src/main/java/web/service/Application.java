package web.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Application {
	public static void main(String[] args) {

		/*//CREATION DE L'HOTEL
		System.out.println("________HOTEL TRIOLET________");
		Adresse adresse_triolet = new Adresse("France","Montpellier","Avenue Augustin Fliche",75,12,15);
		Hotel hotel = new Hotel("Triolet",adresse_triolet,3);
		System.out.println("_____________________________");
		System.out.println("___________CHAMBRES__________");

		// CREATION CHAMBRES
		Chambre chambre1 = new Chambre(1, 2, 130);
		hotel.addChambre(chambre1);

		Chambre chambre2 = new Chambre(2, 2, 150);
		hotel.addChambre(chambre2);

		Chambre chambre3 = new Chambre(3, 3, 200);
		hotel.addChambre(chambre3);
		System.out.println("_____________________________");
		// CREATION CLIENTS
		CarteCredit carte_client1 = new CarteCredit("Chenini", "Ayoub", 1290387594, LocalDate.of(2024, 1, 8), 452);
		Client client1 = new Client("CHENINI", "Ayoub", carte_client1);

		CarteCredit carte_client2 = new CarteCredit("Doe", "John", 1234567890, LocalDate.of(2023, 12, 31), 789);
		Client client2 = new Client("DOE", "John", carte_client2);

		//RESERVATION CLIENTS
		hotel.reserver(client1, "2023- 2- 3", "2023-2-8", 3);
		hotel.reserver(client2,"2023-2-4","2023-2-7", 3);*/

	}
	
}
