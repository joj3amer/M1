@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.web/")
package web.service;
