package common;

public interface Iespece {
    void setDureeVie(int duree_vie);
    void setNomEspece(String nom_espece);
    int getDureeVie();
    String getNomEspece();

}
