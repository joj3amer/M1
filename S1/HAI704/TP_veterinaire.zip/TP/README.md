
# TP1 - RMI

# Introduction

Utilisation de RMI dans le cadre d'un cabinet véterinaire qui gère des patients (animaux)
de différentes espèces et races. Chaque client est associé à un maitre et un dossier de suivi.

# Utilisation

Lancer d'abord le serveur, si il ne se lance pas, de-commenter la ligne avec ma methode `getRegistery()` et commenter celle avec `createRegistery();`

Ensuite lancer le main de la classe `Client`.

# A faire

Les tests, notamments les tests unitaire mais également une classe main qui gère le cabinet, arrivé des patients, mise à jour des dossiers de suivi, etc...
